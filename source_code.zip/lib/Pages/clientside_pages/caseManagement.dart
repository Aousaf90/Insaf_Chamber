import 'package:flutter/material.dart';

class caseManagement extends StatefulWidget {
  const caseManagement({Key? key}) : super(key: key);

  @override
  _caseManagementState createState() => _caseManagementState();
}

class _caseManagementState extends State<caseManagement> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("Case Management"),
      ),
    );
  }
}
